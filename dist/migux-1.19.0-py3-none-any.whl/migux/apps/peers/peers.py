# -*- coding: utf-8 -*-
#
# --- BEGIN_HEADER ---
#
# peers.py - functions for serving the peers app
# Copyright (C) 2025 - 2026  SCIENCE HPC Center at UCPH
#
# This file is part of MiGrid-UX.
#
# MiGrid-UX is free software: you can redistribute it and/or modify it under
# the terms of the GNU General Public License version 2 (LICENSES/LICENSE.GPLv2 or
# https://opensource.org/license/gpl-2.0) or any later version
# at your option. The MiGrid-UX files may NOT be copied, modified, or
# distributed except according to those terms.
#
# --- END_HEADER ---

"""
Route definitions for migux.apps.peers
"""

import os


class _FieldObjectIterator:
    """
    Allow for-in iteration of a known set of fields of an arbitrary
    listing of similarly structured result objects.

    At present this is an implementation detail of FieldObjectListing
    and is not meant to be instantiated separately.
    """

    def __init__(self, field_names):
        self._current_field_index = 0
        self._field_object = None
        self._field_names = field_names

    def __getattr__(self, name):
        return self._field_object[name]

    def __iter__(self):
        return self

    def __next__(self):
        if self._current_field_index == len(self._field_names):
            raise StopIteration()
        current_field_name = self._field_names[self._current_field_index]
        try:
            current_field_value = self._field_object[current_field_name]
        except KeyError:
            # the requested field did not existing in the listing object
            current_field_value = ""
        self._current_field_index += 1
        return current_field_value

    def set_field_object(self, field_object):
        """
        Update the iterator with a reference a dictionary
        that will be indexed into on the next iteration.
        """

        self._field_object = field_object
        self._current_field_index = 0
        return self


class FieldObjectListing:
    """
    Wrapper to allow iteration of result object listings which arranges that
    each entry itself is wrapped such that only requested fields are returned.
    """

    def __init__(self, field_objects, field_names):
        self._entry_wrapper = _FieldObjectIterator(field_names)
        if field_objects is not None:
            self._objects_iterator = iter(field_objects)
        else:
            self._objects_iterator = iter([])

    def __iter__(self):
        return self

    def __next__(self):
        return self._entry_wrapper.set_field_object(
            next(self._objects_iterator)
        )


def list_peers_accepted(request, data=None):
    """
    Generate render_info for the listing of accepted peers.
    """

    field_names = request.args.get("fields", [])

    return {
        "template_args": {
            "peers_listing": FieldObjectListing(data, field_names),
        },
        "template_name": "search_result--accepted",
    }


def list_peers_requested(request, data=None):
    """
    Generate render_info for the listing of requested peers.
    """

    field_names = request.args.get("fields", [])

    return {
        "template_args": {
            "peers_listing": FieldObjectListing(data, field_names),
        },
        "template_name": "search_result",
    }


def list_csrf_tokens(request, data=None):
    """
    Generate render_info for the listing of tokens.
    """

    field_names = request.args.get("fields", [])

    return {
        "template_args": {
            "csrf_tokens": FieldObjectListing(data, field_names),
        },
        "template_name": "csrf_tokens",
    }


TEMPLATE_FOLDER = os.path.join(os.path.dirname(__file__), "templates")
TEMPLATE_ROUTES = {
    "GET /accepted": {
        "generate_args": list_peers_accepted,
    },
    "GET /requested": {
        "generate_args": list_peers_requested,
    },
    "GET /csrf_tokens": {
        "generate_args": list_csrf_tokens,
    },
}
